#!/usr/bin/python
import os
usr=raw_input("User Name:")
os.system("ssh -X "+ usr +"@192.168.112.162 bc")



#!/usr/bin/python
import os
userid=raw_input("enter your userid:")
a=os.system("rpm -q fuse-sshfs")
if a != 0:
	os.system("yum install fuse-sshfs -y")
os.system('mkdir /media/'+userid)
os.system('sshfs '+userid+'@192.168.112.162:/mnt/'+userid+'  /media/'+userid)

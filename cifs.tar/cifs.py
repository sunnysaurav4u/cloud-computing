#!/usr/bin/python
import os
userid=raw_input("enter the user name:")
a=os.system("rpm -q cifs-utils")
if a != 0:
	os.system("yum install cifs-utils -y")
os.system('mkdir /media/'+userid)
os.system('mount -o username='+userid+' //192.168.112.162/'+userid+'  /media/'+userid)

#nfs client side
import os

usrid = raw_input("Enter your userid : ")

#discovery
os.system("iscsiadm --mode discoverydb --type sendtargets --portal 192.168.112.162 --discover")
#login
ec=os.system("iscsiadm --mode node --targetname "+usrid+" --portal 192.168.112.162:3260 --login")
